import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;


public class LoginPageOrangeHRM {
    public static void main(String[] args) {
    
        // This is needed to tell Selenium where to find the ChromeDriver executable
        // Set the system property for ChromeDriver
        System.setProperty("webdriver.chrome.driver", "F:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");

        // 1. Launch Chrome browser
        WebDriver driver = new ChromeDriver();
        
        //maximize window
        driver.manage().window().maximize();

        // 2. Mention URL
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        
        
         // Implicit wait for elements to load on the login page
        // This tells Selenium to wait for 3 seconds before throwing an exception if an element isn't found
        //wait in login page
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

        
        
        // 3. Find username textbox
        WebElement usernametextbox = driver.findElement(By.name("username"));

        // 4. Enter value
        usernametextbox.sendKeys("Admin");

        // 5. Find password textbox
        WebElement passwordtextbox = driver.findElement(By.name("password"));

        // 6. Enter value
        passwordtextbox.sendKeys("admin123");

        // 7. Find login button 
        WebElement loginbtn = driver.findElement(By.xpath("//button[@type='submit']"));

        // 8. Click the button
        loginbtn.click();
    }
}
